<?php

return array (
  'singular' => 'SEO',
  'plural' => 'SEOs',
  'fields' =>
  array (
    'id' => 'Id',
    'language' => 'Language',
    'title' => 'Title',
    'description' => 'Description',
    'keywords' => 'Keywords',
    'page' => 'Page',
    'status' => 'Status',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
