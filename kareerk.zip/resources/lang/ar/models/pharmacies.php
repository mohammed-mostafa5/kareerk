<?php

return array (
  'singular' => 'Pharmacy',
  'plural' => 'Pharmacies',
  'fields' => 
  array (
    'id' => 'Id',
    'name' => 'Name',
    'address' => 'Address',
    'status' => 'Status',
    'code' => 'Code',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
