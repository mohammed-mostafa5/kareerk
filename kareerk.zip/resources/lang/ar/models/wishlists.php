<?php

return array(
  'singular' => 'Wishlist',
  'plural' => 'Wishlists',
  'fields' =>
  array(
    'id' => 'Id',
    'user_id' => 'User Id',
    'product_title' => 'Product Title',
  ),
);
