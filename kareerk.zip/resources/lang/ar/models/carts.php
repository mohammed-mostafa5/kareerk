<?php

return array(
  'singular' => 'Cart',
  'plural' => 'Carts',
  'noProducts' => 'The Cart Is Empty.',
  'fields' =>
  array(
    'id' => 'Id',
    'user_id' => 'User Id',
  ),
);
