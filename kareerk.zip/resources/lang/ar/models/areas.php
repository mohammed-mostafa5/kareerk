<?php

return array (
  'singular' => 'Area',
  'plural' => 'Areas',
  'fields' => 
  array (
    'id' => 'Id',
    'text' => 'Text',
    'status' => 'Status',
  ),
);
