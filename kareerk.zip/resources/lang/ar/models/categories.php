<?php

return array (
  'singular' => 'Category',
  'plural' => 'Categories',
  'fields' => 
  array (
    'id' => 'Id',
    'name' => 'Name',
    'photo' => 'Photo',
    'status' => 'Status',
    'type' => 'Type',
  ),
);
