<?php

return array (
  'singular' => 'Setting',
  'plural' => 'Settings',
  'fields' =>
  array (
    'id' => 'Id',
    'key' => 'Key',
    'value' => 'Value',
  ),
);
