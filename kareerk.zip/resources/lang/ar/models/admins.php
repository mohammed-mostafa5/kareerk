<?php

return array (
  'singular' => 'Admin',
  'plural' => 'Admins',
  'fields' => 
  array (
    'id' => 'Id',
    'name' => 'Name',
    'email' => 'Email',
    'password' => 'Password',
    'password_confirmation' => 'Password Confirmation',
    'roles' => 'Roles',
    'status' => 'Status',
    'remember_token' => 'Remember Token',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
