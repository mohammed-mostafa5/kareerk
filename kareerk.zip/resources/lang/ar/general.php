<?php

return  [
    'chooseCompany' => 'Choose Company',
    'choosePage' => 'Choose Page',
    'viewSpecs' => 'View Specs'
];
