<?php

return array(
    'singular' => 'Skill',
    'plural' => 'Skills',
    'fields' =>
    array(
        'id' => 'Id',
        'service' => 'Service Name',
        'status' => 'Status',
        'type' => 'Type',
        'name' => 'Name',
        'created_at' => 'Created At',
        'updated_at' => 'Updated At',
    ),
);
