<?php

return array(
    'singular' => 'Milestone',
    'plural' => 'Milestones',
    'fields' =>
    array(
        'id' => 'Id',
        'duration' => 'Duration',
        'amount' => 'Amount',
        'title' => 'Title',
        'description' => 'Description',
        'status' => 'Status',
        'job' => 'Job',
        'freelancer' => 'Freelancer',
        'client' => 'Client',
        'admin_status' => 'Admin Status',
        'expected_start' => 'Expected Start',
        'payment_at' => 'Payment At',
        'finished_at' => 'Finished At',
        'created_at' => 'Created At',
        'updated_at' => 'Updated At',
    ),
);
