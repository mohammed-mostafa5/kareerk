<?php

return array (
  'singular' => 'Feature',
  'plural' => 'Features',
  'fields' => 
  array (
    'id' => 'Id',
    'name' => 'Name',
  ),
);
