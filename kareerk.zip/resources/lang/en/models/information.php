<?php

return array(
    'singular' => 'Contact Information',
    'plural' => 'Contact Informations',
    'fields' =>
    array(
        'id' => 'Id',
        'name' => 'Name',
        'value' => 'Value',
        'status' => 'Status',
    ),
);
