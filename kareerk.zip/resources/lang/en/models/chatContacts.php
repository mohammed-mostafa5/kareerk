<?php

return array (
  'singular' => 'ChatContact',
  'plural' => 'ChatContacts',
  'fields' => 
  array (
    'id' => 'Id',
    'chat_id' => 'Chat Id',
    'user_id' => 'User Id',
    'other_user_id' => 'Other User Id',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
