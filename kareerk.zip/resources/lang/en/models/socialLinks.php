<?php

return array (
  'singular' => 'SocialLink',
  'plural' => 'SocialLinks',
  'fields' => 
  array (
    'id' => 'Id',
    'name' => 'Name',
    'link' => 'Link',
    'status' => 'Status',
  ),
);
