<?php

return array (
  'singular' => 'Language',
  'plural' => 'Languages',
  'fields' => 
  array (
    'id' => 'Id',
    'name' => 'Name',
    'status' => 'Status',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
