<?php

return array(
    'singular' => 'Career Request',
    'plural' => 'Career Requests',
    'fields' =>
    array(
        'id' => 'Id',
        'career_id' => 'Career',
        'name' => 'Name',
        'email' => 'Email',
        'phone' => 'Phone',
        'cover_letter' => 'Cover Letter',
        'cv' => 'Cv',
        'created_at' => 'Created At',
        'updated_at' => 'Updated At',
    ),
);
