<?php

return array(
    'singular' => 'Services',
    'plural' => 'Services',
    'fields' =>
    array(
        'id' => 'ID',
        'parent' => 'Parent',
        'photo' => 'Photo',
        'name' => 'Name',
        'status'  => 'Status',
        'type'  => 'Type',
        'created_at' => 'Created At',
        'updated_at' => 'Updated At',
    ),
);
