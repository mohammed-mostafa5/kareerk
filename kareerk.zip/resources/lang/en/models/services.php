<?php

return array(
    'singular' => 'Services',
    'plural' => 'Services',
    'fields' =>
    array(
        'id' => 'ID',
        'parent' => 'Parent',
        'photo' => 'Photo',
        'cover' => 'Cover',
        'name' => 'Name',
        'description' => 'Description',
        'status'  => 'Status',
        'in_home'  => 'In Home ?',
        'type'  => 'Type',
        'created_at' => 'Created At',
        'updated_at' => 'Updated At',
    ),
);
