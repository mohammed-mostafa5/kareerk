<?php

return array (
  'singular' => 'Client',
  'plural' => 'Clients',
  'fields' => 
  array (
    'id' => 'Id',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
