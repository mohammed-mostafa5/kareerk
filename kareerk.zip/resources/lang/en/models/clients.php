<?php

return array(
    'singular' => 'Client',
    'plural' => 'Clients',
    'fields' =>
    array(
        'id' => 'Id',
        'name' => 'Name',
        'email' => 'Email',
        'phone' => 'Phone',
        'created_at' => 'Created At',
        'updated_at' => 'Updated At',
    ),
);
