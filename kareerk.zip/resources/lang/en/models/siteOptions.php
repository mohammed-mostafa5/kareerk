<?php

return array(
    'singular' => 'SiteOption',
    'plural' => 'SiteOptions',
    'fields' =>
    array(
        'id' => 'ID',
        'job_fees' => 'Job Fees',
        'featured_fees' => 'Featured Fees',
        'milestone_percentage' => 'Milestone Percentage',
        'created_at' => 'Created At',
        'updated_at' => 'Updated At',
    ),
);
