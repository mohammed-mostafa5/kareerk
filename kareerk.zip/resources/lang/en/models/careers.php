<?php

return array(
    'singular' => 'Career',
    'plural' => 'Careers',
    'fields' =>
    array(
        'id' => 'ID',
        'title' => 'Title',
        'description' => 'Description',
        'brief' => 'Brief',
        'created_at' => 'Created At',
        'updated_at' => 'Updated At',
    ),
);
