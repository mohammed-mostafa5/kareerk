<?php

return array(
    'singular' => 'Career',
    'plural' => 'Careers',
    'fields' =>
    array(
        'id' => 'ID',
        'title' => 'Title',
        'description' => 'Description',
        'created_at' => 'Created At',
        'updated_at' => 'Updated At',
    ),
);
