<?php

return array (
  'singular' => 'Freelancer',
  'plural' => 'Freelancers',
  'fields' => 
  array (
    'id' => 'Id',
    'main_service_id' => 'Main Service Id',
    'expertise_level' => 'Expertise Level',
    'hourly_rate' => 'Hourly Rate',
    'title' => 'Title',
    'overview' => 'Overview',
    'photo' => 'Photo',
    'city' => 'City',
    'address' => 'Address',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
