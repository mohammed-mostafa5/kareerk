<?php

return array (
  'singular' => 'Message',
  'plural' => 'Messages',
  'fields' => 
  array (
    'id' => 'Id',
    'chat_id' => 'Chat Id',
    'user_id' => 'User Id',
    'text' => 'Text',
    'seen' => 'Seen',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
