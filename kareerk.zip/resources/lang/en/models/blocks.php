<?php

return array(
    'singular' => 'Block',
    'plural' => 'Blocks',
    'fields' =>
    array(
        'id' => 'Id',
        'photo' => 'Photo',
        'title' => 'Title',
        'description' => 'Description',
        'page_id' => 'Page',
    ),
);
