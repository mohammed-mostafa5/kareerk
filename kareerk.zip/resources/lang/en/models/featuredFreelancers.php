<?php

return array(
    'singular' => 'Featured Freelancer',
    'plural' => 'Featured Freelancers',
    'fields' =>
    array(
        'id' => 'Id',
        'freelancer_id' => 'Freelancer',
        'start_at' => 'Start At',
        'end_at' => 'End At',
        'value' => 'Value',
    ),
);
