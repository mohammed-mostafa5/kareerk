<?php

return array (
  'singular' => 'Chat',
  'plural' => 'Chats',
  'fields' => 
  array (
    'id' => 'Id',
    'name' => 'Name',
    'created_by' => 'Created By',
    'latest_message' => 'Latest Message',
    'created_at' => 'Created At',
    'updated_at' => 'Updated At',
  ),
);
