<?php

return array (
  'singular' => 'Package',
  'plural' => 'Packages',
  'fields' => 
  array (
    'id' => 'Id',
    'name' => 'Name',
    'price' => 'Price',
    'duration' => 'Duration',
  ),
);
