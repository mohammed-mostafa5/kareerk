<?php

return array(
    'singular' => 'Country',
    'plural' => 'Countries',
    'fields' =>
    array(
        'id' => 'ID',
        'name' => 'Name',
        'status' => 'Status',
        'created_at' => 'Created At',
        'updated_at' => 'Updated At',
    ),
);
