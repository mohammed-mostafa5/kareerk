<?php

return array(
    'singular' => 'Faq',
    'plural' => 'Faqs',
    'fields' =>
    array(
        'id' => 'ID',
        'action' => 'Action',
        'name' => 'Name',
        'question' => 'Question',
        'answer' => 'Answer',
        'category' => 'Category',
        'faq_category_id' => 'Faq Category',
    ),
);
