<?php

return array (
  'singular' => 'Delivery',
  'plural' => 'Deliveries',
  'fields' =>
  array (
    'id' => 'Id',
    'duration' => 'Duration (Days)',
    'cost' => 'Cost',
    'text' => 'Text',
    'description' => 'Description',
  ),
);
