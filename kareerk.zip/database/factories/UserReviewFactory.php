<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\UserReview;
use Faker\Generator as Faker;

$factory->define(UserReview::class, function (Faker $faker) {
    return [
        //
    ];
});
