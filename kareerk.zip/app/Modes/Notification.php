<?php

namespace App\Modes;

use Illuminate\Database\Eloquent\Model;

class Notification extends Model
{
    //
}
